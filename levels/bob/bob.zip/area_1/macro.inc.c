const MacroObject bob_area_1_macro_objs[] = {
	MACRO_OBJECT_END(),
};

